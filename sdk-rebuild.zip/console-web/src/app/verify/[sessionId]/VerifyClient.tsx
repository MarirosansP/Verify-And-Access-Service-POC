"use client";

/**
 * VerifyClient — uses @concordium/verification-web-ui SDK
 *
 * The SDK handles the entire WalletConnect flow:
 *   QR codes, session management, VP requests, branding — everything.
 *
 * Our job is simply:
 *   1. Create a VP request via our API
 *   2. Mount the SDK with that request
 *   3. Listen for the VP event when the wallet responds
 *   4. Submit the VP to our backend for verification
 *   5. Redirect on success
 */

import React, { useState, useEffect, useRef, useCallback } from "react";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface Props {
  sessionId: string;
  challenge: string;
  siteName: string;
  siteUrl: string;
  callbackUrl: string;
}

type FlowState =
  | "idle"
  | "creating-request"
  | "sdk-mounted"
  | "verifying"
  | "success"
  | "failed";

/* ------------------------------------------------------------------ */
/*  Component                                                          */
/* ------------------------------------------------------------------ */

export default function VerifyClient({
  sessionId,
  challenge,
  siteName,
  siteUrl,
  callbackUrl,
}: Props) {
  const [state, setState] = useState<FlowState>("idle");
  const [statusMsg, setStatusMsg] = useState(
    "Click below to start verification."
  );
  const [error, setError] = useState<string | null>(null);
  const [redirectUrl, setRedirectUrl] = useState<string | null>(null);

  // DOM element the SDK will render into
  const mountRef = useRef<HTMLDivElement>(null);
  // Keep a reference to the original VP request so we can send it with
  // the VP for server-side verification
  const vpRequestRef = useRef<any>(null);
  // Track whether we've already processed a VP event (avoid double-fires)
  const vpHandledRef = useRef(false);

  /* ---- Submit VP to our backend ---- */
  const submitVP = useCallback(
    async (vp: any) => {
      setState("verifying");
      setStatusMsg("Verifying your proof\u2026");

      try {
        const resp = await fetch(`/api/worker/submit-vp/${sessionId}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            presentation: vp,
            verificationRequest: vpRequestRef.current,
          }),
        });

        const data = await resp.json();

        if (data.verified) {
          setState("success");
          setStatusMsg("\u2705 Verification successful! Redirecting\u2026");

          const sep = callbackUrl.includes("?") ? "&" : "?";
          const redirect = `${callbackUrl}${sep}va_session=${sessionId}&va_status=verified`;
          setRedirectUrl(redirect);

          setTimeout(() => {
            window.location.href = redirect;
          }, 2000);
        } else {
          setState("failed");
          setError(data.reason || "Verification failed");
          setStatusMsg("\u274C Verification failed.");
        }
      } catch (err: any) {
        console.error("[VerifyClient] Verification submit error:", err);
        setState("failed");
        setError(err.message || "Verification request failed");
        setStatusMsg("\u274C Something went wrong.");
      }
    },
    [sessionId, callbackUrl]
  );

  /* ---- Listen for VP events from the SDK ---- */
  useEffect(() => {
    if (state !== "sdk-mounted") return;

    const handleVPEvent = (e: Event) => {
      if (vpHandledRef.current) return;

      const detail = (e as CustomEvent).detail;
      console.log("[VerifyClient] VP event received:", e.type, detail);

      // Extract the VP from the event — the SDK wraps it various ways
      let vp: any;
      if (detail?.verifiablePresentationJson) {
        try {
          vp = JSON.parse(detail.verifiablePresentationJson);
        } catch {
          vp = detail.verifiablePresentationJson;
        }
      } else if (detail?.verifiablePresentation) {
        vp = detail.verifiablePresentation;
      } else {
        vp = detail;
      }

      if (!vp) {
        console.warn("[VerifyClient] VP event had no usable payload");
        return;
      }

      vpHandledRef.current = true;
      submitVP(vp);
    };

    // The SDK may dispatch VP events on these channels
    const channels = [
      "concordium-event",
      "verification-web-ui-event",
      "concordium-vp",
    ];
    channels.forEach((ch) => document.addEventListener(ch, handleVPEvent));

    return () => {
      channels.forEach((ch) =>
        document.removeEventListener(ch, handleVPEvent)
      );
    };
  }, [state, submitVP]);

  /* ---- Start the verification flow ---- */
  const startVerification = useCallback(async () => {
    setState("creating-request");
    setStatusMsg("Creating verification request\u2026");
    setError(null);
    vpHandledRef.current = false;

    try {
      /* Step 1 — Create the VP request via our server-side API */
      const vpResp = await fetch(
        `/api/worker/create-vp-request/${sessionId}`,
        { method: "POST" }
      );

      if (!vpResp.ok) {
        const err = await vpResp
          .json()
          .catch(() => ({ error: "Unknown error" }));
        throw new Error(
          err.error || err.detail || "Failed to create VP request"
        );
      }

      const vpData = await vpResp.json();
      console.log("[VerifyClient] VP request created:", vpData);

      // Store the request for later verification
      vpRequestRef.current = vpData;

      /* Step 2 — Dynamically import the SDK (browser-only, no SSR) */
      const mod = await import("@concordium/verification-web-ui");
      const ConcordiumVerificationWebUI =
        mod.ConcordiumVerificationWebUI || mod.default;

      // Also import the styles
      try {
        await import("@concordium/verification-web-ui/styles");
      } catch {
        // CSS import might fail depending on bundler config — non-fatal
        console.warn("[VerifyClient] Could not import SDK styles");
      }

      const projectId =
        process.env.NEXT_PUBLIC_WC_PROJECT_ID ||
        "76324905a70fe5c388bab46d3e0564dc";

      const sdk = new ConcordiumVerificationWebUI({
        network: "mainnet",
        projectId,
        metadata: {
          name: "Verify & Access",
          description: `Age verification for ${siteName}`,
          url: window.location.origin,
          icons: [],
        },
      });

      /* Step 3 — Mount the SDK into our DOM container */
      if (mountRef.current) {
        mountRef.current.innerHTML = "";

        sdk.mount(mountRef.current, {
          request: vpData,
          onStateChange: (sdkState: string) => {
            console.log("[VerifyClient] SDK state:", sdkState);
            setStatusMsg(`Verification: ${sdkState}`);
          },
        });
      }

      setState("sdk-mounted");
      setStatusMsg(
        "Follow the steps below to verify your age\u2026"
      );
    } catch (err: any) {
      console.error("[VerifyClient] Error:", err);
      setState("failed");
      setError(err.message || "An unexpected error occurred");
      setStatusMsg("\u274C Something went wrong.");
    }
  }, [sessionId, siteName]);

  /* ---- Render ---- */
  return (
    <div style={styles.wrapper}>
      {/* Status message */}
      <div style={styles.statusBar}>
        {(state === "creating-request" || state === "verifying") && (
          <Spinner />
        )}
        <span style={styles.statusText}>{statusMsg}</span>
      </div>

      {/* SDK mount point — the SDK renders QR code, modals, etc. here */}
      <div ref={mountRef} id="sdkMount" style={styles.sdkContainer} />

      {/* Start button — shown only before SDK is mounted */}
      {state === "idle" && (
        <button onClick={startVerification} style={styles.startBtn}>
          Start Private Verification &rarr;
        </button>
      )}

      {/* Error display with retry */}
      {error && (
        <div style={styles.errorBox}>
          <strong>Error:</strong> {error}
          <br />
          <button onClick={startVerification} style={styles.retryBtn}>
            Try Again
          </button>
        </div>
      )}

      {/* Success with manual redirect link */}
      {state === "success" && redirectUrl && (
        <div style={styles.successBox}>
          <p>
            Redirecting to <strong>{siteName}</strong>&hellip;
          </p>
          <a href={redirectUrl} style={styles.link}>
            Click here if not redirected automatically
          </a>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Spinner                                                            */
/* ------------------------------------------------------------------ */

function Spinner() {
  return (
    <span style={styles.spinner}>
      <svg
        width="18"
        height="18"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M12 2v4M12 18v4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M2 12h4M18 12h4M4.93 19.07l2.83-2.83M16.24 7.76l2.83-2.83">
          <animateTransform
            attributeName="transform"
            type="rotate"
            values="0 12 12;360 12 12"
            dur="1s"
            repeatCount="indefinite"
          />
        </path>
      </svg>
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Styles                                                             */
/* ------------------------------------------------------------------ */

const styles: Record<string, React.CSSProperties> = {
  wrapper: {
    marginTop: "1.5rem",
  },
  statusBar: {
    display: "flex",
    alignItems: "center",
    gap: "0.5rem",
    padding: "0.75rem 1rem",
    background: "#f8fafc",
    borderRadius: "8px",
    marginBottom: "1rem",
  },
  statusText: {
    fontSize: "0.9rem",
    color: "#334155",
  },
  spinner: {
    display: "inline-flex",
    color: "#2563eb",
  },
  sdkContainer: {
    minHeight: "0",
  },
  startBtn: {
    width: "100%",
    padding: "0.9rem",
    background: "#2563eb",
    color: "#fff",
    border: "none",
    borderRadius: "8px",
    fontSize: "1rem",
    fontWeight: 600,
    cursor: "pointer",
  },
  errorBox: {
    background: "#fef2f2",
    border: "1px solid #fecaca",
    borderRadius: "8px",
    padding: "1rem",
    color: "#991b1b",
    fontSize: "0.9rem",
    marginTop: "1rem",
  },
  retryBtn: {
    marginTop: "0.5rem",
    padding: "0.5rem 1rem",
    background: "#dc2626",
    color: "#fff",
    border: "none",
    borderRadius: "6px",
    fontSize: "0.85rem",
    cursor: "pointer",
  },
  successBox: {
    background: "#f0fdf4",
    border: "1px solid #bbf7d0",
    borderRadius: "8px",
    padding: "1rem",
    color: "#166534",
    fontSize: "0.9rem",
    textAlign: "center" as const,
    marginTop: "1rem",
  },
  link: {
    color: "#2563eb",
    textDecoration: "underline",
  },
};
