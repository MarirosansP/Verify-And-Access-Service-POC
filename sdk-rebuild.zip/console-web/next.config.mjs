/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,

  // Transpile the Concordium verification SDK so Next.js can
  // process its CSS imports and ESM exports correctly.
  transpilePackages: ["@concordium/verification-web-ui"],
};

export default nextConfig;
